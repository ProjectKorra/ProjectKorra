package com.projectkorra.projectkorra.waterbending;

import com.projectkorra.projectkorra.BendingPlayer;
import com.projectkorra.projectkorra.GeneralMethods;
import com.projectkorra.projectkorra.ProjectKorra;
import com.projectkorra.projectkorra.ability.AvatarState;
import com.projectkorra.projectkorra.earthbending.EarthMethods;
import com.projectkorra.projectkorra.firebending.FireBlast;
import com.projectkorra.projectkorra.util.BlockSource;
import com.projectkorra.projectkorra.util.ClickType;
import com.projectkorra.projectkorra.util.TempBlock;

import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;

public class WaterWall {

	public static ConcurrentHashMap<Integer, WaterWall> instances = new ConcurrentHashMap<Integer, WaterWall>();
	public static ConcurrentHashMap<Block, Block> affectedblocks = new ConcurrentHashMap<Block, Block>();
	public static ConcurrentHashMap<Block, Player> wallblocks = new ConcurrentHashMap<Block, Player>();

	private static int selectRANGE = ProjectKorra.plugin.getConfig().getInt("Abilities.Water.Surge.Wall.SelectRange");
	private static final double defaultradius = ProjectKorra.plugin.getConfig().getDouble("Abilities.Water.Surge.Wall.Radius");
	// private static double speed = 1.5;
	private static final long interval = 30;
	private static final byte full = 0x0;
	// private static final byte half = 0x4;

	Player player;
	private Location location = null;
	private Block sourceblock = null;
	// private Block oldwater = null;
	private Location firstdestination = null;
	private Location targetdestination = null;
	private Vector firstdirection = null;
	private Vector targetdirection = null;
	// private boolean falling = false;
	private boolean progressing = false;
	private boolean settingup = false;
	private boolean forming = false;
	private boolean frozen = false;
	private long time;
	private double radius = defaultradius;
	private int selectRange = selectRANGE;

	@SuppressWarnings("deprecation")
	public WaterWall(Player player) {
		this.player = player;

		if (Wave.instances.containsKey(player.getEntityId())) {
			Wave wave = Wave.instances.get(player.getEntityId());
			if (!wave.progressing) {
				Wave.launch(player);
				return;
			}
		}

		if (AvatarState.isAvatarState(player)) {
			radius = AvatarState.getValue(radius);
		}
		if (instances.containsKey(player.getEntityId())) {
			if (instances.get(player.getEntityId()).progressing) {
				freezeThaw(player);
			} else if (prepare()) {
				if (instances.containsKey(player.getEntityId())) {
					instances.get(player.getEntityId()).cancel();
				}
				// Methods.verbose("New water wall prepared");
				instances.put(player.getEntityId(), this);
				time = System.currentTimeMillis();

			}
		} else if (prepare()) {
			if (instances.containsKey(player.getEntityId())) {
				instances.get(player.getEntityId()).cancel();
			}
			instances.put(player.getEntityId(), this);
			time = System.currentTimeMillis();
		}

		BendingPlayer bPlayer = GeneralMethods.getBendingPlayer(player.getName());

		if (bPlayer.isOnCooldown("Surge"))
			return;

		if (!instances.containsKey(player.getEntityId()) && WaterReturn.hasWaterBottle(player)) {

			Location eyeloc = player.getEyeLocation();
			Block block = eyeloc.add(eyeloc.getDirection().normalize()).getBlock();
			if (EarthMethods.isTransparentToEarthbending(player, block) && EarthMethods.isTransparentToEarthbending(player, eyeloc.getBlock())) {
				block.setType(Material.WATER);
				block.setData(full);
				Wave wave = new Wave(player);
				wave.canhitself = false;
				wave.moveWater();
				if (!wave.progressing) {
					block.setType(Material.AIR);
					wave.cancel();
				} else {
					WaterReturn.emptyWaterBottle(player);
				}
			}

		}

	}

	private static void freezeThaw(Player player) {
		instances.get(player.getEntityId()).freezeThaw();
	}

	private void freezeThaw() {
		if (!WaterMethods.canIcebend(player))
			return;

		if (frozen) {
			thaw();
		} else {
			freeze();
		}
	}

	private void freeze() {
		frozen = true;
		for (Block block : wallblocks.keySet()) {
			if (wallblocks.get(block) == player) {
				new TempBlock(block, Material.ICE, (byte) 0);
				WaterMethods.playIcebendingSound(block.getLocation());
			}
		}
	}

	private void thaw() {
		frozen = false;
		for (Block block : wallblocks.keySet()) {
			if (wallblocks.get(block) == player) {
				new TempBlock(block, Material.STATIONARY_WATER, (byte) 8);
			}
		}
	}

	public boolean prepare() {
		cancelPrevious();
		// Block block = player.getTargetBlock(null, (int) range);
		Block block = BlockSource.getWaterSourceBlock(player, selectRange, selectRange, ClickType.LEFT_CLICK, false, true, true, WaterMethods.canIcebend(player), WaterMethods.canPlantbend(player));
		if (block != null) {
			sourceblock = block;
			focusBlock();
			return true;
		}
		return false;
	}

	private void cancelPrevious() {
		if (instances.containsKey(player.getEntityId())) {
			WaterWall old = instances.get(player.getEntityId());
			if (old.progressing) {
				old.removeWater(old.sourceblock);
			} else {
				old.cancel();
			}
		}
	}

	public void cancel() {
		unfocusBlock();
	}

	private void focusBlock() {
		location = sourceblock.getLocation();
	}

	private void unfocusBlock() {
		instances.remove(player.getEntityId());
	}

	@SuppressWarnings("deprecation")
	public void moveWater() {
		if (sourceblock != null) {
			targetdestination = player.getTargetBlock(EarthMethods.getTransparentEarthbending(), selectRange).getLocation();

			if (targetdestination.distance(location) <= 1) {
				progressing = false;
				targetdestination = null;
			} else {
				progressing = true;
				settingup = true;
				firstdestination = getToEyeLevel();
				firstdirection = getDirection(sourceblock.getLocation(), firstdestination);
				targetdirection = getDirection(firstdestination, targetdestination);
				if (WaterMethods.isPlant(sourceblock))
					new Plantbending(sourceblock);
				if (!GeneralMethods.isAdjacentToThreeOrMoreSources(sourceblock)) {
					sourceblock.setType(Material.AIR);
				}
				addWater(sourceblock);
			}

		}
	}

	private Location getToEyeLevel() {
		Location loc = sourceblock.getLocation().clone();
		loc.setY(targetdestination.getY());
		return loc;
	}

	private Vector getDirection(Location location, Location destination) {
		double x1, y1, z1;
		double x0, y0, z0;

		x1 = destination.getX();
		y1 = destination.getY();
		z1 = destination.getZ();

		x0 = location.getX();
		y0 = location.getY();
		z0 = location.getZ();

		return new Vector(x1 - x0, y1 - y0, z1 - z0);

	}

	public static void progressAll() {
		for (int ID : instances.keySet()) {
			instances.get(ID).progress();
		}
	}

	private boolean progress() {
		if (player.isDead() || !player.isOnline()) {
			breakBlock();
			// instances.remove(player.getEntityId());
			return false;
		}
		if (!GeneralMethods.canBend(player.getName(), "Surge")) {
			//if (!forming)
			// removeWater(oldwater);
			breakBlock();
			returnWater(location);
			unfocusBlock();
			return false;
		}

		if (System.currentTimeMillis() - time >= interval) {
			time = System.currentTimeMillis();

			if (!forming) {
				// removeWater(oldwater);
			}

			if (GeneralMethods.getBoundAbility(player) == null) {
				unfocusBlock();
				breakBlock();
				returnWater(location);
				return false;
			}
			if (!progressing && !GeneralMethods.getBoundAbility(player).equalsIgnoreCase("Surge")) {
				unfocusBlock();
				return false;
			}

			if (progressing && (!player.isSneaking() || !GeneralMethods.getBoundAbility(player).equalsIgnoreCase("Surge"))) {
				breakBlock();
				returnWater(location);
				return false;
			}

			if (!progressing) {
				sourceblock.getWorld().playEffect(location, Effect.SMOKE, 4, selectRange);
				return false;
			}

			if (forming) {
				if (GeneralMethods.rand.nextInt(7) == 0) {
					WaterMethods.playWaterbendingSound(location);
				}
				ArrayList<Block> blocks = new ArrayList<Block>();
				Location loc = GeneralMethods.getTargetedLocation(player, selectRange, 8, 9, 79);
				location = loc.clone();
				Vector dir = player.getEyeLocation().getDirection();
				Vector vec;
				Block block;
				for (double i = 0; i <= WaterMethods.waterbendingNightAugment(radius, player.getWorld()); i += 0.5) {
					for (double angle = 0; angle < 360; angle += 10) {
						// loc.getBlock().setType(Material.GLOWSTONE);
						vec = GeneralMethods.getOrthogonalVector(dir.clone(), angle, i);
						block = loc.clone().add(vec).getBlock();
						if (GeneralMethods.isRegionProtectedFromBuild(player, "Surge", block.getLocation()))
							continue;
						if (wallblocks.containsKey(block)) {
							blocks.add(block);
						} else if (!blocks.contains(block) && (block.getType() == Material.AIR || block.getType() == Material.FIRE || WaterMethods.isWaterbendable(block, player))) {
							wallblocks.put(block, player);
							addWallBlock(block);
							// if (frozen) {
							// block.setType(Material.ICE);
							// } else {
							// block.setType(Material.WATER);
							// block.setData(full);
							// }
							// block.setType(Material.GLASS);
							blocks.add(block);
							FireBlast.removeFireBlastsAroundPoint(block.getLocation(), 2);
							// Methods.verbose(wallblocks.size());
						}
					}
				}

				for (Block blocki : wallblocks.keySet()) {
					if (wallblocks.get(blocki) == player && !blocks.contains(blocki)) {
						finalRemoveWater(blocki);
					}
				}

				return true;
			}

			if (sourceblock.getLocation().distance(firstdestination) < .5 && settingup) {
				settingup = false;
			}

			Vector direction;
			if (settingup) {
				direction = firstdirection;
			} else {
				direction = targetdirection;
			}

			location = location.clone().add(direction);

			Block block = location.getBlock();
			if (block.getLocation().equals(sourceblock.getLocation())) {
				location = location.clone().add(direction);
				block = location.getBlock();
			}
			if (block.getType() != Material.AIR) {
				breakBlock();
				returnWater(location.subtract(direction));
				return false;
			}

			if (!progressing) {
				breakBlock();
				return false;
			}

			addWater(block);
			removeWater(sourceblock);
			sourceblock = block;

			if (location.distance(targetdestination) < 1) {

				removeWater(sourceblock);
				// removeWater(oldwater);
				forming = true;
			}

			return true;
		}

		return false;

	}

	private void addWallBlock(Block block) {
		if (frozen) {
			new TempBlock(block, Material.ICE, (byte) 0);
		} else {
			new TempBlock(block, Material.STATIONARY_WATER, (byte) 8);
		}
	}

	private void breakBlock() {
		finalRemoveWater(sourceblock);
		for (Block block : wallblocks.keySet()) {
			if (wallblocks.get(block) == player) {
				finalRemoveWater(block);
			}
		}
		instances.remove(player.getEntityId());
	}

	// private void reduceWater(Block block) {
	// if (affectedblocks.containsKey(block)) {
	// if (!Methods.adjacentToThreeOrMoreSources(block)) {
	// block.setType(Material.WATER);
	// block.setData(half);
	// }
	// oldwater = block;
	// }
	// }

	private void removeWater(Block block) {
		if (block != null) {
			if (affectedblocks.containsKey(block)) {
				if (!GeneralMethods.isAdjacentToThreeOrMoreSources(block)) {
					TempBlock.revertBlock(block, Material.AIR);
				}
				affectedblocks.remove(block);
			}
		}
	}

	private static void finalRemoveWater(Block block) {
		if (affectedblocks.containsKey(block)) {
			// block.setType(Material.WATER);
			// block.setData(half);
			// if (!Methods.adjacentToThreeOrMoreSources(block)) {
			// block.setType(Material.AIR);
			// }
			TempBlock.revertBlock(block, Material.AIR);
			affectedblocks.remove(block);
		}

		if (wallblocks.containsKey(block)) {
			// if (block.getType() == Material.ICE
			// || block.getType() == Material.WATER
			// || block.getType() == Material.STATIONARY_WATER) {
			// block.setType(Material.AIR);
			// }
			TempBlock.revertBlock(block, Material.AIR);
			wallblocks.remove(block);
			// block.setType(Material.WATER);
			// block.setData(half);
		}
	}

	private void addWater(Block block) {

		if (GeneralMethods.isRegionProtectedFromBuild(player, "Surge", block.getLocation()))
			return;

		if (!TempBlock.isTempBlock(block)) {
			new TempBlock(block, Material.STATIONARY_WATER, (byte) 8);
			// new TempBlock(block, Material.ICE, (byte) 0);
			affectedblocks.put(block, block);
		}
	}

	public static void moveWater(Player player) {
		if (instances.containsKey(player.getEntityId())) {
			instances.get(player.getEntityId()).moveWater();
		}
	}

	public static boolean progress(int ID) {
		return instances.get(ID).progress();
	}

	@SuppressWarnings("deprecation")
	public static void form(Player player) {

		if (!instances.containsKey(player.getEntityId())) {
			if (!Wave.instances.containsKey(player.getEntityId()) && BlockSource.getWaterSourceBlock(player, Wave.defaultrange, Wave.defaultrange, ClickType.LEFT_CLICK, false, true, true, WaterMethods.canIcebend(player), WaterMethods.canPlantbend(player)) == null && WaterReturn.hasWaterBottle(player)) {
				BendingPlayer bPlayer = GeneralMethods.getBendingPlayer(player.getName());

				if (bPlayer.isOnCooldown("Surge"))
					return;

				Location eyeloc = player.getEyeLocation();
				Block block = eyeloc.add(eyeloc.getDirection().normalize()).getBlock();
				if (EarthMethods.isTransparentToEarthbending(player, block) && EarthMethods.isTransparentToEarthbending(player, eyeloc.getBlock())) {
					block.setType(Material.WATER);
					block.setData(full);
					WaterWall wall = new WaterWall(player);
					wall.moveWater();
					if (!wall.progressing) {
						block.setType(Material.AIR);
						wall.cancel();
					} else {
						WaterReturn.emptyWaterBottle(player);
					}
					return;
				}
			}

			new Wave(player);
			return;
		} else {
			if (WaterMethods.isWaterbendable(player.getTargetBlock((HashSet<Material>) null, (int) Wave.defaultrange), player)) {
				new Wave(player);
				return;
			}
		}

		moveWater(player);
	}

	public static void removeAll() {
		for (Block block : affectedblocks.keySet()) {
			TempBlock.revertBlock(block, Material.AIR);
			affectedblocks.remove(block);
			wallblocks.remove(block);
		}
		for (Block block : wallblocks.keySet()) {
			TempBlock.revertBlock(block, Material.AIR);
			affectedblocks.remove(block);
			wallblocks.remove(block);
		}
	}

	public static boolean canThaw(Block block) {
		if (wallblocks.keySet().contains(block))
			return false;
		return true;
	}

	public static void thaw(Block block) {
		finalRemoveWater(block);
	}

	public static boolean wasBrokenFor(Player player, Block block) {
		if (instances.containsKey(player.getEntityId())) {
			WaterWall wall = instances.get(player.getEntityId());
			if (wall.sourceblock == null)
				return false;
			if (wall.sourceblock.equals(block))
				return true;
		}
		return false;
	}

	private void returnWater(Location location) {
		if (location != null) {
			new WaterReturn(player, location.getBlock());
		}
	}

	public static String getDescription() {
		return "This ability has two distinct features. If you sneak to select a source block, " + "you can then click in a direction and a large wave will be launched in that direction. " + "If you sneak again while the wave is en route, the wave will freeze the next target it hits. " + "If, instead, you click to select a source block, you can hold sneak to form a wall of water at " + "your cursor location. Click to shift between a water wall and an ice wall. " + "Release sneak to dissipate it.";
	}

	public Player getPlayer() {
		return player;
	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	public double getRange() {
		return selectRange;
	}

	public void setRange(int range) {
		this.selectRange = range;
	}

}