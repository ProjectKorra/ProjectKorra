package com.projectkorra.projectkorra.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import com.projectkorra.projectkorra.GeneralMethods;
import com.projectkorra.projectkorra.configuration.ConfigManager;
import com.projectkorra.projectkorra.earthbending.EarthMethods;
import com.projectkorra.projectkorra.waterbending.WaterMethods;

/**
 * BlockSource is a class that handles water and earth bending sources. When a Player left clicks or
 * presses shift the update method is called which attempts to update the player's sources.
 * 
 * In this class ClickType refers to the way in which the source was selected. For example, Surge
 * has two different ways to select a source, one involving shift and another involving left clicks.
 */
public class BlockSource {
	/**
	 * An enum representation of the source types available for bending abilities.
	 */
	public static enum BlockSourceType {
		WATER, ICE, PLANT, EARTH, METAL, LAVA, SAND
	}

	private static List<Block> randomBlocks = new ArrayList<Block>();
	private static HashMap<Player, BlockSourceInformation> playerSources = new HashMap<Player, BlockSourceInformation>();
	private static FileConfiguration config = ConfigManager.defaultConfig.get();
	// The player should never need to grab source blocks from farther than this.
	private static double MAX_RANGE = config.getDouble("Abilities.Water.WaterManipulation.Range");

	/**
	 * Updates all of the player's sources.
	 * 
	 * @param player the player performing the bending.b
	 * @param clickType either {@link ClickType}.SHIFT_DOWN or ClickType.LEFT_CLICK
	 */
	public static void update(Player player, ClickType clickType, int maxSelectTimes) {
		String boundAbil = GeneralMethods.getBoundAbility(player);
		if (boundAbil == null) {
			return;
		}
		if (WaterMethods.isWaterAbility(boundAbil)) {
			Block waterBlock = WaterMethods.getWaterSourceBlock(player, MAX_RANGE, true);
			if (waterBlock != null) {
				putSource(player, waterBlock, BlockSourceType.WATER, clickType, maxSelectTimes);
				if (WaterMethods.isPlant(waterBlock)) {
					putSource(player, waterBlock, BlockSourceType.PLANT, clickType, maxSelectTimes);
				}
				if (WaterMethods.isIcebendable(waterBlock)) {
					putSource(player, waterBlock, BlockSourceType.ICE, clickType, maxSelectTimes);
				}
			}
		} else if (EarthMethods.isEarthAbility(boundAbil)) {
			Block earthBlock = EarthMethods.getEarthSourceBlock(player, MAX_RANGE);
			if (earthBlock != null) {
				putSource(player, earthBlock, BlockSourceType.EARTH, clickType, maxSelectTimes);
				if (EarthMethods.isMetal(earthBlock)) {
					putSource(player, earthBlock, BlockSourceType.METAL, clickType, maxSelectTimes);
				}
				if (EarthMethods.isSand(earthBlock)) {
					putSource(player, earthBlock, BlockSourceType.SAND, clickType, maxSelectTimes);
				}
			}

			// We need to handle lava differently, since getEarthSourceBlock doesn't account for
			// lava. We should only select the lava source if it is closer than the earth.
			Block lavaBlock = EarthMethods.getLavaSourceBlock(player, MAX_RANGE);
			double earthDist = earthBlock != null ? earthBlock.getLocation().distanceSquared(player.getLocation())
					: Double.MAX_VALUE;
			double lavaDist = lavaBlock != null ? lavaBlock.getLocation().distanceSquared(player.getLocation())
					: Double.MAX_VALUE;
			if (lavaBlock != null && lavaDist <= earthDist) {
				putSource(player, null, BlockSourceType.EARTH, clickType, maxSelectTimes);
				putSource(player, lavaBlock, BlockSourceType.LAVA, clickType, maxSelectTimes);
			}
		}
	}

	/**
	 * Helper method to create and update a specific source.
	 * 
	 * @param player a player.
	 * @param block the block that is considered a source.
	 * @param sourceType the elemental type of the block.
	 * @param clickType the type of click, either SHIFT_DOWN or LEFT_CLICK.
	 */
	private static void putSource(Player player, Block block, BlockSourceType sourceType, ClickType clickType,
			int maxSelectTimes) {
		BlockSourceInformation info = new BlockSourceInformation(player, block, sourceType, clickType, maxSelectTimes);
		if (playerSources.containsKey(player)) {
			removeSource(player);
		}
		playerSources.put(player, info);
	}

	private static void removeSource(Player player) {
		if (!playerSources.containsKey(player)) {
			return;
		}
		playerSources.remove(player);
	}

	/**
	 * Access a block's source information, depending on a {@link BlockSourceType} and
	 * {@link ClickType}.
	 * 
	 * @param player the player that is trying to bend.
	 * @param clickType the action that was performed to access the source, either
	 *            ClickType.SHIFT_DOWN or ClickType.LEFT_CLICK.
	 * @return a valid bendable block, or null if none was found.
	 */
	public static BlockSourceInformation getBlockSourceInformation(Player player) {
		if (!playerSources.containsKey(player)) {
			return null;
		}
		return playerSources.get(player);
	}

	/**
	 * Access a block source information depending on a range, {@link BlockSourceType}, and
	 * {@link ClickType}.
	 * 
	 * @param player the player that is trying to bend.
	 * @param range the maximum range to access the block.
	 * @param sourceType the elemental type of block to find.
	 * @param clickType the action that was performed to access the source, either
	 *            ClickType.SHIFT_DOWN or ClickType.LEFT_CLICK.
	 * @return a valid bendable block, or null if none was found.
	 */
	public static BlockSourceInformation getValidBlockSourceInformation(Player player, double range, BlockSourceType sourceType,
			ClickType clickType) {
		BlockSourceInformation blockInfo = getBlockSourceInformation(player);
		return isStillAValidSource(blockInfo, range, clickType) ? blockInfo : null;
	}

	/**
	 * Access a specific type of source block depending on a range and {@link ClickType}.
	 * 
	 * @param player the player that is trying to bend.
	 * @param range the maximum range to access the block.
	 * @param sourceType the elemental type of block to find.
	 * @param clickType the action that was performed to access the source, either
	 *            ClickType.SHIFT_DOWN or ClickType.LEFT_CLICK.
	 * @return a valid bendable block, or null if none was found.
	 */

	public static Block getDynamicEarthSourceBlock(Player player, int range, BlockSourceType sourceType, ClickType clickType,
			boolean allowAuto, boolean allowNearbySubstitute, boolean allowMetal, boolean allowLava, boolean allowSand,
			boolean allowEarth, int maxSelectTimes) {
		Block sourceBlock = null;
		if (allowNearbySubstitute && sourceBlock == null) {
			BlockSourceInformation info = getBlockSourceInformation(player);
			if (info != null) {
				Block tempBlock = info.getBlock();
				if (tempBlock != null) {
					info.selectTimes++;
					if (info.selectTimes >= info.getMaxSelectTimes()) {
						removeSource(player);
					}
					sourceBlock = EarthMethods.getNearbyEarthBlock(tempBlock.getLocation(), 3, 3);
					info.setBlock(sourceBlock);
					return sourceBlock;
				}
			}
		}
		if (allowEarth && sourceBlock == null && EarthMethods.getEarthSourceBlock(player, range) != null) {
			sourceBlock = EarthMethods.getEarthSourceBlock(player, range);
			putSource(player, sourceBlock, BlockSourceType.EARTH, clickType, maxSelectTimes);
			return sourceBlock;
		} else if (allowSand && sourceBlock == null && EarthMethods.getSandSourceBlock(player, range) != null) {
			sourceBlock = EarthMethods.getSandSourceBlock(player, range);
			putSource(player, sourceBlock, BlockSourceType.SAND, clickType, maxSelectTimes);
			return sourceBlock;
		} else if (allowAuto && getRandomEarthSourceBlock(player, range, allowMetal, allowLava, allowSand, allowEarth) != null) {
			sourceBlock = getRandomEarthSourceBlock(player, range, allowMetal, allowLava, allowSand, allowEarth);
			if (EarthMethods.isEarth(sourceBlock)) {
				sourceType = BlockSourceType.EARTH;
			} else if (EarthMethods.isSand(sourceBlock)) {
				sourceType = BlockSourceType.SAND;
			}
			putSource(player, sourceBlock, sourceType, clickType, maxSelectTimes);
			return sourceBlock;
		}
		return null;
	}

	public static Block getDynamicWaterSourceBlock(Player player, int range, BlockSourceType sourceType, ClickType clickType,
			boolean allowAuto, boolean allowPlant, boolean allowIce, boolean allowWater) {
		Block sourceBlock = null;
		BlockSourceInformation info = getValidBlockSourceInformation(player, range, sourceType, clickType);
		if (info != null) {
			sourceBlock = info.getBlock();
		} else if (allowAuto) {
			if (sourceBlock == null) {
				sourceBlock = getRandomWaterSourceBlock(player, range, allowPlant, allowIce, allowWater);
			}
		} else if (sourceBlock == null) {
			if (WaterMethods.getWaterSourceBlock(player, range, false) != null && allowWater) {
				sourceBlock = WaterMethods.getWaterSourceBlock(player, range, false);
			} else if (WaterMethods.getIceSourceBlock(player, range) != null && allowIce) {
				sourceBlock = WaterMethods.getIceSourceBlock(player, range);
			} else if (WaterMethods.getPlantSourceBlock(player, range, false) != null && allowPlant) {
				sourceBlock = WaterMethods.getPlantSourceBlock(player, range, false);
			}
		}
		return sourceBlock;
	}

	public static Block getRandomEarthSourceBlock(Player player, int radius, boolean allowMetal, boolean allowLava,
			boolean allowSand, boolean allowEarth) {
		Location location = player.getLocation();
		List<Integer> checked = new ArrayList<Integer>();
		List<Block> blocks = GeneralMethods.getBlocksAroundPoint(location, radius);
		for (int i = 0; i < blocks.size(); i++) {
			int index = GeneralMethods.rand.nextInt(blocks.size());
			while (checked.contains(index)) {
				index = GeneralMethods.rand.nextInt(blocks.size());
			}
			Block block = blocks.get(index);
			if (block.getRelative(BlockFace.UP).getType() == Material.AIR && block != null) {
				if (EarthMethods.isEarthbendable(block.getType()) && allowEarth) {
					randomBlocks.add(block);
					return block;
				} else if (EarthMethods.isSand(block) && allowSand) {
					randomBlocks.add(block);
					return block;
				} else if (EarthMethods.isLava(block) && allowLava) {
					randomBlocks.add(block);
					return block;
				} else if (EarthMethods.isMetal(block) && allowMetal) {
					randomBlocks.add(block);
					return block;
				}
			}
		}
		return null;
	}

	public static Block getRandomWaterSourceBlock(Player player, int radius, boolean allowPlant, boolean allowIce,
			boolean allowWater) {
		Location location = player.getLocation();
		Block block = null;
		List<Integer> checked = new ArrayList<Integer>();
		List<Block> blocks = GeneralMethods.getBlocksAroundPoint(location, radius);
		for (int i = 0; i < blocks.size(); i++) {
			int index = GeneralMethods.rand.nextInt(blocks.size());
			while (checked.contains(index)) {
				index = GeneralMethods.rand.nextInt(blocks.size());
			}
			block = blocks.get(index);
			if (block.getRelative(BlockFace.UP).getType() == Material.AIR && block != null) {
				if (WaterMethods.isWater(block) && allowWater)
					break;
				else if (WaterMethods.isIcebendable(block) && allowIce)
					break;
				else if (WaterMethods.isPlant(block) && allowPlant)
					break;
			}
		}
		return block;
	}

	/**
	 * Attempts to access a Water bendable block that was recently shifted or clicked on by the
	 * player.
	 * 
	 * @param player the player that is trying to bend.
	 * @param range the maximum range to access the block.
	 * @param clickType the action that was performed to access the source, either {@link ClickType}
	 *            .SHIFT_DOWN or ClickType.LEFT_CLICK.
	 * @param allowWater true if water blocks are allowed.
	 * @param allowIce true if ice blocks are allowed.
	 * @param allowPlant true if plant blocks are allowed.
	 * @param allowWaterBottles true if we should look for a close water block, that may have been
	 *            created by a WaterBottle.
	 * @return a valid Water bendable block, or null if none was found.
	 */
	public static Block getWaterSourceBlock(Player player, int range, ClickType clickType, boolean allowWaterBottles,
			boolean allowPlant, boolean allowIce, boolean allowWater, boolean allowAuto, boolean allowDynamic) {
		Block sourceBlock = null;
		if (allowWaterBottles) {
			// Check the block in front of the player's eyes, it may have been created by a
			// WaterBottle.
			return WaterMethods.getWaterSourceBlock(player, range, allowPlant);
		} else if (allowDynamic) {
			if (allowWater) {
				return getDynamicWaterSourceBlock(player, range, BlockSourceType.WATER, clickType, allowAuto, false, false, true);
			}
			if (allowIce) {
				return getDynamicWaterSourceBlock(player, range, BlockSourceType.ICE, clickType, allowAuto, false, true, false);
			}
			if (allowPlant) {
				return getDynamicWaterSourceBlock(player, range, BlockSourceType.PLANT, clickType, allowAuto, true, false, false);
			}
		} else if (allowAuto) {
			return getRandomWaterSourceBlock(player, range, allowPlant, allowIce, allowWater);
		} else {
			if (WaterMethods.getWaterSourceBlock(player, range, false) != null && allowWater) {
				sourceBlock = WaterMethods.getWaterSourceBlock(player, range, false);
			} else if (WaterMethods.getIceSourceBlock(player, range) != null && allowIce) {
				sourceBlock = WaterMethods.getIceSourceBlock(player, range);
			} else if (WaterMethods.getPlantSourceBlock(player, range, false) != null && allowPlant) {
				sourceBlock = WaterMethods.getPlantSourceBlock(player, range, false);
			}
		}
		if (sourceBlock != null) {
			randomBlocks.add(sourceBlock);
			return sourceBlock;
		}
		return null;
	}

	/**
	 * Attempts to access a Earth bendable block that was recently shifted or clicked on by the
	 * player.
	 * 
	 * @param player the player that is trying to bend.
	 * @param range the maximum range to access the block.
	 * @param clickType the action that was performed to access the source, either {@link ClickType}
	 *            .SHIFT_DOWN or ClickType.LEFT_CLICK.
	 * @param allowNearbySubstitute if a valid earth source could not be found then this method will
	 *            attempt to find a nearby valid earth block.
	 * @return a valid Earth bendable block, or null if none was found.
	 */

	public static Block getEarthSourceBlock(Player player, int range, ClickType clickType, boolean allowMetal, boolean allowLava,
			boolean allowSand, boolean allowEarth, boolean allowAuto, boolean allowNearbySubstitute, boolean allowDynamic,
			int maxSelectTimes) {
		Block sourceBlock = null;
		if (allowDynamic) {
			if (allowEarth && getDynamicEarthSourceBlock(player, range, BlockSourceType.EARTH, clickType, allowAuto,
					allowNearbySubstitute, false, false, false, true, maxSelectTimes) != null) {
				sourceBlock = getDynamicEarthSourceBlock(player, range, BlockSourceType.EARTH, clickType, allowAuto,
						allowNearbySubstitute, false, false, false, true, maxSelectTimes);
				return sourceBlock;
			}
			if (allowSand && sourceBlock == null && getDynamicEarthSourceBlock(player, range, BlockSourceType.SAND, clickType,
					allowAuto, allowNearbySubstitute, false, false, true, false, maxSelectTimes) != null) {
				sourceBlock = getDynamicEarthSourceBlock(player, range, BlockSourceType.SAND, clickType, allowAuto,
						allowNearbySubstitute, false, false, true, false, maxSelectTimes);
				return sourceBlock;
			}
		}
		if (allowEarth && sourceBlock == null && EarthMethods.getEarthSourceBlock(player, range) != null) {
			sourceBlock = EarthMethods.getEarthSourceBlock(player, range);
			return sourceBlock;
		} else if (allowSand && sourceBlock == null && EarthMethods.getSandSourceBlock(player, range) != null) {
			sourceBlock = EarthMethods.getSandSourceBlock(player, range);
			return sourceBlock;
		} else if (allowAuto && sourceBlock == null
				&& getRandomEarthSourceBlock(player, range, allowMetal, allowLava, allowSand, allowEarth) != null) {
			sourceBlock = getRandomEarthSourceBlock(player, range, allowMetal, allowLava, allowSand, allowEarth);
			return sourceBlock;
		}
		return null;
	}

	public static boolean isAuto(Block block) {
		if (randomBlocks.contains(block)) {
			return true;
		}
		return false;
	}

	/**
	 * Determines if a BlockSourceInformation is valid, depending on the players range from the
	 * source, and if the source has not been modified since the time that it was first created.
	 * 
	 * @param info the source information.
	 * @param range the maximum bending range.
	 * @return true if it is valid.
	 */
	private static boolean isStillAValidSource(BlockSourceInformation info, double range, ClickType clickType) {
		if (info == null || info.getBlock() == null || info.selectTimes > info.getMaxSelectTimes()) {
			return false;
		} else if (info.getClickType() != clickType) {
			return false;
		} else if (!info.getPlayer().getWorld().equals(info.getBlock().getWorld())) {
			return false;
		} else if (Math.abs(info.getPlayer().getLocation().distance(info.getBlock().getLocation())) > range) {
			return false;
		} else if (info.getSourceType() == BlockSourceType.WATER
				&& !WaterMethods.isWaterbendable(info.getBlock(), info.getPlayer())) {
			return false;
		} else if (info.getSourceType() == BlockSourceType.ICE && !WaterMethods.isIcebendable(info.getBlock())) {
			return false;
		} else if (info.getSourceType() == BlockSourceType.PLANT
				&& (!WaterMethods.isPlant(info.getBlock()) || !WaterMethods.isWaterbendable(info.getBlock(), info.getPlayer()))) {
			return false;
		} else if (info.getSourceType() == BlockSourceType.EARTH
				&& !EarthMethods.isEarthbendable(info.getPlayer(), info.getBlock())) {
			return false;
		} else if (info.getSourceType() == BlockSourceType.METAL
				&& (!EarthMethods.isMetal(info.getBlock()) || !EarthMethods.isEarthbendable(info.getPlayer(), info.getBlock()))) {
			return false;
		} else if (info.getSourceType() == BlockSourceType.LAVA
				&& (!EarthMethods.isLava(info.getBlock()) || !EarthMethods.isLavabendable(info.getBlock(), info.getPlayer()))) {
			return false;
		} else if (info.getSourceType() == BlockSourceType.SAND && !EarthMethods.isSand(info.getBlock())
				|| !EarthMethods.isSand(info.getBlock())) {
			return false;
		}
		return true;
	}
}
